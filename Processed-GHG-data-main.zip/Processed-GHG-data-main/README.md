# Processed-GHG-data
Processed data used for the inversion

The file contains hourly CO2, CH4 and CO data along with their uncertainties used for the inversion. 
